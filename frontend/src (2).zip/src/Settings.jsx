﻿import { useEffect, useMemo, useState } from "react";
import "./Settings.css";

const API_URL = (
  import.meta.env.VITE_API_URL || "https://testflow-pkbi.onrender.com"
).replace(/\/$/, "");

const THEME_STORAGE_KEY = "testflow_student_theme";

const DEFAULT_SETTINGS = {
  theme: "system",
  notifications: {
    testReminders: true,
    results: true,
    securityAlerts: true,
    emailNotifications: true,
  },
  examPreferences: {
    fullscreen: true,
    violationMonitoring: true,
    secureExamMode: true,
    autoSave: true,
  },
  general: {
    dateFormat: "DD/MM/YYYY",
    timeFormat: "12-hour",
    confirmLogout: true,
  },
};

/* =========================================================
   HELPERS
========================================================= */

function getToken() {
  return (
    localStorage.getItem("studentToken") ||
    localStorage.getItem("accessToken") ||
    sessionStorage.getItem("studentToken") ||
    sessionStorage.getItem("accessToken") ||
    ""
  );
}

function cloneDefaults() {
  return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
}

function normalizeTheme(theme) {
  return ["light", "dark", "system"].includes(theme) ? theme : "system";
}

function mergeSettings(value = {}) {
  const defaults = cloneDefaults();

  return {
    ...defaults,
    ...value,
    theme: normalizeTheme(value.theme),

    notifications: {
      ...defaults.notifications,
      ...(value.notifications || {}),
    },

    examPreferences: {
      ...defaults.examPreferences,
      ...(value.examPreferences || {}),
    },

    general: {
      ...defaults.general,
      ...(value.general || {}),
    },
  };
}

/* =========================================================
   GLOBAL THEME
========================================================= */

function applyGlobalTheme(theme, persist = true) {
  const normalizedTheme = normalizeTheme(theme);

  const root = document.documentElement;
  const body = document.body;

  const themeClasses = [
    "settings-light",
    "settings-system",
    "settings-dark",
    "theme-light",
    "theme-system",
    "theme-dark",
  ];

  root.classList.remove(...themeClasses);
  body.classList.remove(...themeClasses);

  root.classList.add(`settings-${normalizedTheme}`);
  body.classList.add(`settings-${normalizedTheme}`);

  root.classList.add(`theme-${normalizedTheme}`);
  body.classList.add(`theme-${normalizedTheme}`);

  root.setAttribute("data-theme", normalizedTheme);
  body.setAttribute("data-theme", normalizedTheme);

  if (persist) {
    localStorage.setItem(THEME_STORAGE_KEY, normalizedTheme);
  }

  window.dispatchEvent(
    new CustomEvent("testflow-theme-change", {
      detail: {
        theme: normalizedTheme,
      },
    })
  );
}

function restoreStoredTheme() {
  const storedTheme = normalizeTheme(
    localStorage.getItem(THEME_STORAGE_KEY) || "system"
  );

  applyGlobalTheme(storedTheme, false);

  return storedTheme;
}

/* =========================================================
   COMPONENT
========================================================= */

export default function Settings({ onBack }) {
  const [profile, setProfile] = useState(null);

  const [settings, setSettings] = useState(cloneDefaults());
  const [pendingTheme, setPendingTheme] = useState("system");

  const [loading, setLoading] = useState(true);
  const [savingSettings, setSavingSettings] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);

  const [message, setMessage] = useState({
    type: "",
    text: "",
  });

  const [password, setPassword] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [passwordLoading, setPasswordLoading] = useState(false);
  const [securityLoading, setSecurityLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [studentId, setStudentId] = useState("");

  /* =======================================================
     LOAD SETTINGS
  ======================================================= */

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    setLoading(true);
    setMessage({
      type: "",
      text: "",
    });

    const storedTheme = restoreStoredTheme();
    const token = getToken();

    if (!token) {
      const fallback = mergeSettings({
        theme: storedTheme,
      });

      setSettings(fallback);
      setPendingTheme(storedTheme);
      setLoading(false);

      setMessage({
        type: "error",
        text: "Your student session has expired. Please log in again.",
      });

      return;
    }

    try {
      const response = await fetch(`${API_URL}/api/student/settings`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to load settings (${response.status})`);
      }

      const data = await response.json();

      const savedSettings = mergeSettings(data.settings || {});
      const savedTheme = normalizeTheme(savedSettings.theme);

      const profileData = data.profile || data.student || {};

      setProfile(profileData);

      setName(
        profileData.name ||
          profileData.fullName ||
          profileData.studentName ||
          ""
      );

      setEmail(profileData.email || "");

      setStudentId(
        profileData.studentId ||
          profileData.studentID ||
          profileData.id ||
          ""
      );

      setSettings(savedSettings);
      setPendingTheme(savedTheme);

      applyGlobalTheme(savedTheme);

      if (profileData.name) {
        localStorage.setItem("studentName", profileData.name);
      }

      if (profileData.email) {
        localStorage.setItem("studentEmail", profileData.email);
      }
    } catch (error) {
      console.error("Settings load error:", error);

      const fallback = mergeSettings({
        theme: storedTheme,
      });

      setSettings(fallback);
      setPendingTheme(storedTheme);

      applyGlobalTheme(storedTheme);

      setMessage({
        type: "error",
        text: "Unable to load your settings. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  }

  /* =======================================================
     UPDATE SETTING
  ======================================================= */

  function updateSetting(section, key, value) {
    setSettings((previous) => ({
      ...previous,
      [section]: {
        ...previous[section],
        [key]: value,
      },
    }));
  }

  /* =======================================================
     PROFILE
  ======================================================= */

  async function saveProfile() {
    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    setSavingProfile(true);
    setMessage({
      type: "",
      text: "",
    });

    try {
      const response = await fetch(`${API_URL}/api/student/profile`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.message || data.error || "Failed to update profile."
        );
      }

      const updatedProfile = data.profile || {
        ...(profile || {}),
        name: name.trim(),
        email: email.trim(),
      };

      setProfile(updatedProfile);

      localStorage.setItem("studentName", name.trim());
      localStorage.setItem("studentEmail", email.trim());

      setMessage({
        type: "success",
        text: "Profile updated successfully.",
      });
    } catch (error) {
      console.error("Profile update error:", error);

      setMessage({
        type: "error",
        text: error.message || "Unable to update your profile.",
      });
    } finally {
      setSavingProfile(false);
    }
  }

  /* =======================================================
     SAVE SETTINGS
  ======================================================= */

  async function saveSettings() {
    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    setSavingSettings(true);
    setMessage({
      type: "",
      text: "",
    });

    const settingsToSave = {
      ...settings,
      theme: normalizeTheme(pendingTheme),
    };

    try {
      const response = await fetch(`${API_URL}/api/student/settings`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settingsToSave),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.message || data.error || "Failed to save settings."
        );
      }

      const savedSettings = mergeSettings(
        data.settings || settingsToSave
      );

      const savedTheme = normalizeTheme(savedSettings.theme);

      setSettings(savedSettings);
      setPendingTheme(savedTheme);

      applyGlobalTheme(savedTheme);

      setMessage({
        type: "success",
        text: "All settings saved successfully.",
      });
    } catch (error) {
      console.error("Settings save error:", error);

      setMessage({
        type: "error",
        text: error.message || "Unable to save your settings.",
      });
    } finally {
      setSavingSettings(false);
    }
  }

  /* =======================================================
     RESET
  ======================================================= */

  async function resetSettings() {
    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    const confirmed = window.confirm(
      "Reset all settings to their default values?"
    );

    if (!confirmed) return;

    setSavingSettings(true);
    setMessage({
      type: "",
      text: "",
    });

    try {
      const response = await fetch(
        `${API_URL}/api/student/settings/reset`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.message || data.error || "Failed to reset settings."
        );
      }

      const resetSettingsData = mergeSettings(
        data.settings || DEFAULT_SETTINGS
      );

      const resetTheme = normalizeTheme(resetSettingsData.theme);

      setSettings(resetSettingsData);
      setPendingTheme(resetTheme);

      applyGlobalTheme(resetTheme);

      setMessage({
        type: "success",
        text: "Settings have been restored to their defaults.",
      });
    } catch (error) {
      console.error("Settings reset error:", error);

      setMessage({
        type: "error",
        text: error.message || "Unable to reset your settings.",
      });
    } finally {
      setSavingSettings(false);
    }
  }

  /* =======================================================
     PASSWORD
  ======================================================= */

  async function changePassword(event) {
    event.preventDefault();

    if (!password.currentPassword) {
      setMessage({
        type: "error",
        text: "Enter your current password.",
      });
      return;
    }

    if (!password.newPassword) {
      setMessage({
        type: "error",
        text: "Enter a new password.",
      });
      return;
    }

    if (password.newPassword.length < 8) {
      setMessage({
        type: "error",
        text: "New password must be at least 8 characters.",
      });
      return;
    }

    if (password.newPassword !== password.confirmPassword) {
      setMessage({
        type: "error",
        text: "New passwords do not match.",
      });
      return;
    }

    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    setPasswordLoading(true);
    setMessage({
      type: "",
      text: "",
    });

    try {
      const response = await fetch(
        `${API_URL}/api/student/change-password`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            currentPassword: password.currentPassword,
            newPassword: password.newPassword,
          }),
        }
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.message || data.error || "Failed to change password."
        );
      }

      setPassword({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });

      setMessage({
        type: "success",
        text: "Password changed successfully.",
      });
    } catch (error) {
      console.error("Password change error:", error);

      setMessage({
        type: "error",
        text: error.message || "Unable to change your password.",
      });
    } finally {
      setPasswordLoading(false);
    }
  }

  /* =======================================================
     LOGOUT OTHER SESSIONS
  ======================================================= */

  async function logoutOtherSessions() {
    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    const confirmed = window.confirm(
      "This will sign you out of other active sessions. Continue?"
    );

    if (!confirmed) return;

    setSecurityLoading(true);
    setMessage({
      type: "",
      text: "",
    });

    try {
      const response = await fetch(
        `${API_URL}/api/student/logout-other-sessions`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.message ||
            data.error ||
            "Unable to logout other sessions."
        );
      }

      setMessage({
        type: "success",
        text: "Other active sessions have been signed out.",
      });
    } catch (error) {
      console.error("Logout other sessions error:", error);

      setMessage({
        type: "error",
        text:
          error.message ||
          "Unable to logout other active sessions.",
      });
    } finally {
      setSecurityLoading(false);
    }
  }

  /* =======================================================
     EXPORT DATA
  ======================================================= */

  async function exportData() {
    const token = getToken();

    if (!token) {
      setMessage({
        type: "error",
        text: "Your session has expired. Please log in again.",
      });
      return;
    }

    setExportLoading(true);
    setMessage({
      type: "",
      text: "",
    });

    try {
      const response = await fetch(`${API_URL}/api/student/export`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));

        throw new Error(
          data.message || data.error || "Unable to export your data."
        );
      }

      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = url;
      link.download = `testflow-student-data-${Date.now()}.json`;

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(url);

      setMessage({
        type: "success",
        text: "Your data export has been downloaded.",
      });
    } catch (error) {
      console.error("Export data error:", error);

      setMessage({
        type: "error",
        text: error.message || "Unable to export your data.",
      });
    } finally {
      setExportLoading(false);
    }
  }

  /* =======================================================
     THEME
  ======================================================= */

  function handleThemeChange(value) {
    const normalizedTheme = normalizeTheme(value);

    setPendingTheme(normalizedTheme);

    /*
      IMPORTANT:
      Apply immediately for live preview.
      persist=false means it is not permanently saved
      until Save All Changes is clicked.
    */
    applyGlobalTheme(normalizedTheme, false);
  }

  /* =======================================================
     INITIALS
  ======================================================= */

  const initials = useMemo(() => {
    const source =
      name ||
      profile?.name ||
      profile?.fullName ||
      profile?.studentName ||
      "Student";

    const parts = source.trim().split(/\s+/).filter(Boolean);

    if (!parts.length) return "ST";

    if (parts.length === 1) {
      return parts[0].slice(0, 2).toUpperCase();
    }

    return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
  }, [name, profile]);

  const pageTheme = normalizeTheme(pendingTheme);

  const displayStudentId =
    profile?.studentId ||
    profile?.studentID ||
    studentId ||
    "1001";

  /* =======================================================
     LOADING
  ======================================================= */

  if (loading) {
    return (
      <section
        className={`settings-page settings-${pageTheme} settings-loading`}
      >
        <div className="settings-loading-card">
          <div className="settings-spinner" />
          <h2>Loading settings</h2>
          <p>Preparing your TestFlow preferences...</p>
        </div>
      </section>
    );
  }

  /* =======================================================
     RENDER
  ======================================================= */

  return (
    <section
      className={`settings-page settings-${pageTheme}`}
      data-theme={pageTheme}
    >
      <div className="settings-shell">
        {/* HEADER */}

        <div className="settings-heading-row">
          <div>
            <div className="settings-eyebrow">
              STUDENT CONTROL CENTER
            </div>

            <h1>Settings</h1>

            <p>
              Personalize your TestFlow experience, security and
              examination preferences.
            </p>
          </div>

          {onBack && (
            <button
              type="button"
              className="settings-back-button"
              onClick={onBack}
            >
              <span>←</span>
              Back
            </button>
          )}
        </div>

        {/* MESSAGE */}

        {message.text && (
          <div
            className={`settings-message ${
              message.type === "success" ? "success" : "error"
            }`}
            role="alert"
          >
            <span className="settings-message-icon">
              {message.type === "success" ? "✓" : "!"}
            </span>

            <span>{message.text}</span>
          </div>
        )}

        <div className="settings-grid">
          {/* =================================================
              MAIN COLUMN
          ================================================= */}

          <main className="settings-main-column">
            {/* PROFILE */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    ACCOUNT
                  </div>

                  <h2 className="settings-card-title">
                    Profile information
                  </h2>

                  <p className="settings-card-description">
                    Keep your student information up to date.
                  </p>
                </div>

                <div className="settings-card-icon">◎</div>
              </div>

              <div className="profile-preview">
                <div className="settings-avatar">{initials}</div>

                <div className="profile-preview-info">
                  <strong>
                    {name || profile?.name || "Student"}
                  </strong>

                  <span>
                    {email || profile?.email || "No email added"}
                  </span>

                  <div className="student-id-box">
                    <span>Student ID</span>
                    <strong>{displayStudentId}</strong>
                  </div>
                </div>
              </div>

              <div className="settings-form-grid">
                <label className="settings-field">
                  <span>Full name</span>

                  <input
                    type="text"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Enter your full name"
                  />
                </label>

                <label className="settings-field">
                  <span>Email address</span>

                  <input
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="Enter your email"
                  />
                </label>
              </div>

              <div className="settings-footer-actions">
                <button
                  type="button"
                  className="settings-primary"
                  onClick={saveProfile}
                  disabled={savingProfile}
                >
                  {savingProfile ? "Saving..." : "Save Profile"}
                </button>
              </div>
            </section>

            {/* APPEARANCE */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    APPEARANCE
                  </div>

                  <h2 className="settings-card-title">
                    Theme
                  </h2>

                  <p className="settings-card-description">
                    Choose how TestFlow looks across your device.
                  </p>
                </div>

                <div className="settings-card-icon">◐</div>
              </div>

              <div className="theme-options">
                {[
                  [
                    "system",
                    "System",
                    "Automatically follow your device preference.",
                    "◌",
                  ],
                  [
                    "light",
                    "Light",
                    "A clean warm interface for bright environments.",
                    "☼",
                  ],
                  [
                    "dark",
                    "Dark",
                    "A deep premium interface for focused sessions.",
                    "◐",
                  ],
                ].map(([value, title, description, icon]) => (
                  <button
                    type="button"
                    key={value}
                    className={`theme-option ${
                      pendingTheme === value ? "selected" : ""
                    }`}
                    onClick={() => handleThemeChange(value)}
                    aria-pressed={pendingTheme === value}
                  >
                    <span className="theme-icon">{icon}</span>

                    <span className="theme-option-content">
                      <strong>{title}</strong>
                      <small>{description}</small>
                    </span>

                    <span className="theme-radio">
                      {pendingTheme === value ? "✓" : ""}
                    </span>
                  </button>
                ))}
              </div>

              <div className="theme-save-hint">
                <span>●</span>
                Theme preview updates immediately. Click{" "}
                <strong>Save All Changes</strong> to keep it.
              </div>
            </section>

            {/* NOTIFICATIONS */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    NOTIFICATIONS
                  </div>

                  <h2 className="settings-card-title">
                    Notification preferences
                  </h2>

                  <p className="settings-card-description">
                    Control the updates you receive from TestFlow.
                  </p>
                </div>

                <div className="settings-card-icon">⌁</div>
              </div>

              <div className="settings-options-list">
                <Toggle
                  label="Test reminders"
                  description="Receive reminders about upcoming tests."
                  checked={settings.notifications.testReminders}
                  onChange={(value) =>
                    updateSetting(
                      "notifications",
                      "testReminders",
                      value
                    )
                  }
                />

                <Toggle
                  label="Test results"
                  description="Receive notifications when results are available."
                  checked={settings.notifications.results}
                  onChange={(value) =>
                    updateSetting(
                      "notifications",
                      "results",
                      value
                    )
                  }
                />

                <Toggle
                  label="Security alerts"
                  description="Receive important account and security alerts."
                  checked={settings.notifications.securityAlerts}
                  onChange={(value) =>
                    updateSetting(
                      "notifications",
                      "securityAlerts",
                      value
                    )
                  }
                />

                <Toggle
                  label="Email notifications"
                  description="Allow TestFlow to send important emails."
                  checked={settings.notifications.emailNotifications}
                  onChange={(value) =>
                    updateSetting(
                      "notifications",
                      "emailNotifications",
                      value
                    )
                  }
                />
              </div>
            </section>

            {/* EXAM PREFERENCES */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    EXAMINATION
                  </div>

                  <h2 className="settings-card-title">
                    Exam preferences
                  </h2>

                  <p className="settings-card-description">
                    Configure your preferred examination behaviour.
                  </p>
                </div>

                <div className="settings-card-icon">⌘</div>
              </div>

              <div className="settings-options-list">
                <Toggle
                  label="Fullscreen mode"
                  description="Open supported examinations in fullscreen."
                  checked={settings.examPreferences.fullscreen}
                  onChange={(value) =>
                    updateSetting(
                      "examPreferences",
                      "fullscreen",
                      value
                    )
                  }
                />

                <Toggle
                  label="Violation monitoring"
                  description="Monitor examination activity for rule violations."
                  checked={settings.examPreferences.violationMonitoring}
                  onChange={(value) =>
                    updateSetting(
                      "examPreferences",
                      "violationMonitoring",
                      value
                    )
                  }
                />

                <Toggle
                  label="Secure exam mode"
                  description="Use additional security controls during examinations."
                  checked={settings.examPreferences.secureExamMode}
                  onChange={(value) =>
                    updateSetting(
                      "examPreferences",
                      "secureExamMode",
                      value
                    )
                  }
                />

                <Toggle
                  label="Auto-save"
                  description="Automatically save supported examination progress."
                  checked={settings.examPreferences.autoSave}
                  onChange={(value) =>
                    updateSetting(
                      "examPreferences",
                      "autoSave",
                      value
                    )
                  }
                />
              </div>
            </section>

            {/* GENERAL */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    GENERAL
                  </div>

                  <h2 className="settings-card-title">
                    General preferences
                  </h2>

                  <p className="settings-card-description">
                    Configure dates, times and confirmation behaviour.
                  </p>
                </div>

                <div className="settings-card-icon">⚙</div>
              </div>

              <div className="settings-form-grid">
                <label className="settings-field">
                  <span>Date format</span>

                  <select
                    className="settings-select"
                    value={settings.general.dateFormat}
                    onChange={(event) =>
                      updateSetting(
                        "general",
                        "dateFormat",
                        event.target.value
                      )
                    }
                  >
                    <option value="DD/MM/YYYY">
                      DD/MM/YYYY
                    </option>

                    <option value="MM/DD/YYYY">
                      MM/DD/YYYY
                    </option>

                    <option value="YYYY-MM-DD">
                      YYYY-MM-DD
                    </option>
                  </select>
                </label>

                <label className="settings-field">
                  <span>Time format</span>

                  <select
                    className="settings-select"
                    value={settings.general.timeFormat}
                    onChange={(event) =>
                      updateSetting(
                        "general",
                        "timeFormat",
                        event.target.value
                      )
                    }
                  >
                    <option value="12-hour">12-hour</option>
                    <option value="24-hour">24-hour</option>
                  </select>
                </label>
              </div>

              <div className="settings-options-list compact">
                <Toggle
                  label="Confirm logout"
                  description="Ask for confirmation before signing out."
                  checked={settings.general.confirmLogout}
                  onChange={(value) =>
                    updateSetting(
                      "general",
                      "confirmLogout",
                      value
                    )
                  }
                />
              </div>
            </section>

            {/* SAVE */}

            <div className="settings-actions-row">
              <button
                type="button"
                className="settings-secondary"
                onClick={resetSettings}
                disabled={savingSettings}
              >
                Reset Defaults
              </button>

              <button
                type="button"
                className="settings-primary settings-primary-large"
                onClick={saveSettings}
                disabled={savingSettings}
              >
                {savingSettings
                  ? "Saving Changes..."
                  : "Save All Changes"}
              </button>
            </div>
          </main>

          {/* =================================================
              SIDE COLUMN
          ================================================= */}

          <aside className="settings-side-column">
            {/* PASSWORD */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    SECURITY
                  </div>

                  <h2 className="settings-card-title">
                    Change password
                  </h2>

                  <p className="settings-card-description">
                    Keep your account protected with a strong password.
                  </p>
                </div>

                <div className="settings-card-icon">⌑</div>
              </div>

              <form
                className="password-form"
                onSubmit={changePassword}
              >
                <label className="settings-field">
                  <span>Current password</span>

                  <input
                    type="password"
                    value={password.currentPassword}
                    onChange={(event) =>
                      setPassword((previous) => ({
                        ...previous,
                        currentPassword: event.target.value,
                      }))
                    }
                    placeholder="Current password"
                    autoComplete="current-password"
                  />
                </label>

                <label className="settings-field">
                  <span>New password</span>

                  <input
                    type="password"
                    value={password.newPassword}
                    onChange={(event) =>
                      setPassword((previous) => ({
                        ...previous,
                        newPassword: event.target.value,
                      }))
                    }
                    placeholder="Minimum 8 characters"
                    autoComplete="new-password"
                  />
                </label>

                <label className="settings-field">
                  <span>Confirm new password</span>

                  <input
                    type="password"
                    value={password.confirmPassword}
                    onChange={(event) =>
                      setPassword((previous) => ({
                        ...previous,
                        confirmPassword: event.target.value,
                      }))
                    }
                    placeholder="Repeat new password"
                    autoComplete="new-password"
                  />
                </label>

                <button
                  type="submit"
                  className="settings-primary full-width"
                  disabled={passwordLoading}
                >
                  {passwordLoading
                    ? "Changing..."
                    : "Change Password"}
                </button>
              </form>
            </section>

            {/* SECURITY ACTIONS */}

            <section className="settings-card">
              <div className="settings-card-header">
                <div>
                  <div className="settings-card-kicker">
                    ACCOUNT SECURITY
                  </div>

                  <h2 className="settings-card-title">
                    Security actions
                  </h2>

                  <p className="settings-card-description">
                    Manage sessions and your personal data.
                  </p>
                </div>

                <div className="settings-card-icon">◇</div>
              </div>

              <div className="security-actions">
                <button
                  type="button"
                  className="security-action"
                  onClick={logoutOtherSessions}
                  disabled={securityLoading}
                >
                  <span className="security-action-icon">
                    ↗
                  </span>

                  <span>
                    <strong>
                      {securityLoading
                        ? "Signing out..."
                        : "Sign out other sessions"}
                    </strong>

                    <small>
                      End active sessions on other devices.
                    </small>
                  </span>
                </button>

                <button
                  type="button"
                  className="security-action"
                  onClick={exportData}
                  disabled={exportLoading}
                >
                  <span className="security-action-icon">
                    ↓
                  </span>

                  <span>
                    <strong>
                      {exportLoading
                        ? "Preparing export..."
                        : "Export my data"}
                    </strong>

                    <small>
                      Download a copy of your TestFlow data.
                    </small>
                  </span>
                </button>
              </div>
            </section>

            {/* ACCOUNT INFO */}

            <section className="settings-card settings-account-card">
              <div className="account-status">
                <span className="account-status-dot" />

                <div>
                  <strong>Account active</strong>
                  <span>
                    Your TestFlow student account is ready.
                  </span>
                </div>
              </div>

              <div className="account-meta">
                <div>
                  <span>Student ID</span>
                  <strong>{displayStudentId}</strong>
                </div>

                <div>
                  <span>Theme</span>
                  <strong>
                    {pendingTheme.charAt(0).toUpperCase() +
                      pendingTheme.slice(1)}
                  </strong>
                </div>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   TOGGLE COMPONENT
========================================================= */

function Toggle({
  label,
  description,
  checked,
  onChange,
}) {
  return (
    <div className="setting-toggle">
      <div className="setting-toggle-content">
        <strong>{label}</strong>

        <span>{description}</span>
      </div>

      <button
        type="button"
        className={`toggle ${checked ? "active" : ""}`}
        onClick={() => onChange(!checked)}
        aria-pressed={checked}
        aria-label={label}
      >
        <span className="toggle-knob" />
      </button>
    </div>
  );
}