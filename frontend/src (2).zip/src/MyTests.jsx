﻿import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import "./MyTests.css";

const API_BASE = (
  import.meta.env.VITE_API_URL ||
  "http://localhost:5000"
).replace(/\/$/, "");

const STUDENT_TOKEN_KEYS = [
  "studentToken",
  "student_token",
  "token",
  "authToken",
  "accessToken",
];

function getStoredToken() {
  for (const key of STUDENT_TOKEN_KEYS) {
    const localValue = localStorage.getItem(key);
    if (localValue) {
      return localValue;
    }

    const sessionValue = sessionStorage.getItem(key);
    if (sessionValue) {
      return sessionValue;
    }
  }

  return "";
}

function getHeaders() {
  const token = getStoredToken();

  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

function normalizeTest(test) {
  if (!test) {
    return null;
  }

  return {
    paperId: test.paperId || test.paperID || test.id || "",
    subject: test.subject || "Online Examination",
    programmingLanguage: test.programmingLanguage || "",
    topics: test.topics || "",
    totalQuestions: Number(test.totalQuestions) || 0,
    codingQuestions: Number(test.codingQuestions) || 0,
    status: test.status || "published",
    title: test.title || test.subject || "Online Examination",
    duration: Number(test.duration) || 30,
    attempt: test.attempt || null,
    createdAt: test.createdAt || null,
    updatedAt: test.updatedAt || null,
  };
}

function formatTopics(topics) {
  if (!topics) {
    return [];
  }

  if (Array.isArray(topics)) {
    return topics
      .map((item) => String(item).trim())
      .filter(Boolean)
      .slice(0, 4);
  }

  return String(topics)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

function getTestIcon(subject = "") {
  const value = subject.toLowerCase();

  if (value.includes("python") || value.includes("programming")) {
    return "</>";
  }
  if (value.includes("data") || value.includes("algorithm") || value.includes("dsa")) {
    return "❖";
  }
  if (value.includes("database") || value.includes("sql")) {
    return "▤";
  }
  if (value.includes("web") || value.includes("html") || value.includes("javascript")) {
    return "⌘";
  }
  if (value.includes("ai") || value.includes("machine")) {
    return "✦";
  }

  return "T";
}

export default function MyTests({ onStartTest, onBackToDashboard }) {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [startingPaperId, setStartingPaperId] = useState("");

  /*
  ==================================================
  API REQUEST
  ==================================================
  */
  const apiRequest = useCallback(async (path, options = {}) => {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        ...getHeaders(),
        ...(options.headers || {}),
      },
    });

    let data = null;

    try {
      data = await response.json();
    } catch {
      data = null;
    }

    if (!response.ok) {
      throw new Error(
        data?.message || `Request failed with status ${response.status}`
      );
    }

    return data;
  }, []);

  /*
  ==================================================
  LOAD AVAILABLE TESTS
  ==================================================
  */
  const loadTests = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await apiRequest("/api/student/tests");
      const availableTests = Array.isArray(data?.tests) ? data.tests : [];

      const cleanedTests = availableTests
        .map(normalizeTest)
        .filter(Boolean)
        .filter(
          (test, index, array) =>
            array.findIndex((item) => item.paperId === test.paperId) === index
        );

      setTests(cleanedTests);
    } catch (loadError) {
      console.error("My Tests loading error:", loadError);
      setError(
        loadError?.message || "Unable to load your assigned tests."
      );
      setTests([]);
    } finally {
      setLoading(false);
    }
  }, [apiRequest]);

  useEffect(() => {
    loadTests();
  }, [loadTests]);

  /*
  ==================================================
  SEARCH + FILTER
  ==================================================
  */
  const filteredTests = useMemo(() => {
    const searchValue = search.trim().toLowerCase();

    return tests.filter((test) => {
      const subject = test.subject.toLowerCase();
      const language = test.programmingLanguage.toLowerCase();
      const topics = test.topics.toLowerCase();

      const matchesSearch =
        !searchValue ||
        subject.includes(searchValue) ||
        language.includes(searchValue) ||
        topics.includes(searchValue) ||
        test.paperId.toLowerCase().includes(searchValue);

      let matchesFilter = true;

      if (filter === "CODING") {
        matchesFilter = test.codingQuestions > 0;
      }

      if (filter === "MCQ") {
        matchesFilter = test.totalQuestions > test.codingQuestions;
      }

      return matchesSearch && matchesFilter;
    });
  }, [tests, search, filter]);

  /*
  ==================================================
  START / RESUME TEST
  ==================================================
  */
  const handleStartTest = async (test) => {
    if (!test?.paperId) {
      return;
    }

    if (startingPaperId) {
      return;
    }

    setStartingPaperId(test.paperId);
    setError("");

    try {
      console.log(`Loading full test ${test.paperId}...`);

      const fullTestResponse = await apiRequest(
        `/api/student/tests/${encodeURIComponent(test.paperId)}`
      );

      const fullTest = fullTestResponse?.test || fullTestResponse;

      if (!fullTest || !Array.isArray(fullTest.questions)) {
        throw new Error("Unable to load the questions for this test.");
      }

      console.log(
        `Loaded ${fullTest.questions.length} questions for ${test.paperId}`
      );

      console.log(`Starting/resuming attempt for ${test.paperId}...`);

      const response = await apiRequest(
        `/api/student/tests/${encodeURIComponent(test.paperId)}/start`,
        {
          method: "POST",
          body: JSON.stringify({}),
        }
      );

      console.log("Start/resume response:", response);

      const attemptId =
        response?.attemptId ||
        response?.attempt?.attemptId ||
        response?.data?.attemptId ||
        "";

      if (!attemptId) {
        throw new Error("The examination attempt could not be created.");
      }

      localStorage.setItem("attemptId", attemptId);
      localStorage.setItem("studentAttemptId", attemptId);
      localStorage.setItem("examAttemptId", attemptId);

      const testToOpen = {
        ...fullTest,
        attemptId,
        paperId: fullTest.paperId || test.paperId,
        questions: fullTest.questions,
      };

      console.log("Opening StudentTest with:", testToOpen);

      if (typeof onStartTest === "function") {
        await onStartTest(testToOpen);
        return;
      }

      localStorage.setItem("selectedTest", JSON.stringify(testToOpen));
      localStorage.setItem("active_test", JSON.stringify(testToOpen));

      window.location.href = `/student-test/${encodeURIComponent(test.paperId)}`;
    } catch (startError) {
      console.error("Unable to start/resume test:", startError);
      setError(startError?.message || "Unable to start this test.");
    } finally {
      setStartingPaperId("");
    }
  };

  /*
  ==================================================
  RENDER
  ==================================================
  */
  return (
    <div className="my-tests-page">
      <div className="my-tests-header">
        <div>
          <div className="my-tests-eyebrow">EXAMINATION CENTRE</div>
          <h1>My Tests</h1>
          <p>View your available examinations and start a secure test.</p>
        </div>

        <div className="test-count-card">
          <span>AVAILABLE TESTS</span>
          <strong>{tests.length}</strong>
        </div>
      </div>

      <div className="my-tests-toolbar">
        <div className="test-search">
          <span className="search-icon">🔍</span>

          <input
            type="text"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search tests, subjects or topics..."
          />

          {search && (
            <button
              className="clear-search"
              onClick={() => setSearch("")}
              aria-label="Clear search"
            >
              ×
            </button>
          )}
        </div>

        <div className="test-filters">
          <button
            className={filter === "ALL" ? "active" : ""}
            onClick={() => setFilter("ALL")}
          >
            All
          </button>

          <button
            className={filter === "MCQ" ? "active" : ""}
            onClick={() => setFilter("MCQ")}
          >
            MCQ
          </button>

          <button
            className={filter === "CODING" ? "active" : ""}
            onClick={() => setFilter("CODING")}
          >
            Coding
          </button>
        </div>
      </div>

      {error && (
        <div className="my-tests-error">
          <div className="error-icon">!</div>

          <div>
            <strong>Notice</strong>
            <span>{error}</span>
          </div>

          <button onClick={loadTests}>Retry</button>
        </div>
      )}

      {loading ? (
        <div className="tests-loading">
          <div className="loading-spinner" />
          <strong>Loading available tests...</strong>
          <span>Connecting to the examination server</span>
        </div>
      ) : filteredTests.length === 0 ? (
        <div className="empty-tests">
          <div className="empty-icon">✓</div>
          <h2>No tests found</h2>
          <p>
            {tests.length === 0
              ? "There are currently no published examinations available."
              : "No tests match your current search or filter."}
          </p>

          {(search || filter !== "ALL") && (
            <button
              className="reset-filter-button"
              onClick={() => {
                setSearch("");
                setFilter("ALL");
              }}
            >
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <div className="tests-grid">
          {filteredTests.map((test) => {
            const topics = formatTopics(test.topics);
            const isStarting = startingPaperId === test.paperId;

            return (
              <article className="test-card" key={test.paperId}>
                <div className="test-card-top">
                  <div className="test-icon">
                    {getTestIcon(test.subject)}
                  </div>

                  <div className="test-status">
                    <span />
                    {test.attempt?.status === "SUBMITTED"
                      ? "COMPLETED"
                      : test.attempt?.status === "IN_PROGRESS"
                      ? "IN PROGRESS"
                      : "AVAILABLE"}
                  </div>
                </div>

                <div className="test-card-content">
                  <div className="test-label">EXAMINATION</div>
                  <h2>{test.subject}</h2>

                  {test.programmingLanguage && (
                    <div className="language-line">
                      <span>LANGUAGE</span>
                      <strong>{test.programmingLanguage}</strong>
                    </div>
                  )}

                  <div className="test-topic-list">
                    {topics.length > 0 ? (
                      topics.map((topic) => <span key={topic}>{topic}</span>)
                    ) : (
                      <span>General</span>
                    )}
                  </div>
                </div>

                <div className="test-details">
                  <div className="test-detail">
                    <span className="detail-icon">📋</span>
                    <div>
                      <small>QUESTIONS</small>
                      <strong>{test.totalQuestions}</strong>
                    </div>
                  </div>

                  <div className="test-detail">
                    <span className="detail-icon">⚙</span>
                    <div>
                      <small>TYPE</small>
                      <strong>
                        {test.codingQuestions > 0 ? "Mixed" : "MCQ"}
                      </strong>
                    </div>
                  </div>

                  <div className="test-detail">
                    <span className="detail-icon">#</span>
                    <div>
                      <small>PAPER ID</small>
                      <strong>{test.paperId}</strong>
                    </div>
                  </div>
                </div>

                <div className="test-card-footer">
                  <span>Secure AI-proctored examination</span>

                  <button
                    className="start-test-button"
                    onClick={() => handleStartTest(test)}
                    disabled={
                      Boolean(startingPaperId) ||
                      test.attempt?.status === "SUBMITTED" ||
                      test.attempt?.status === "FLAGGED" ||
                      test.attempt?.status === "TERMINATED"
                    }
                  >
                    {isStarting
                      ? "STARTING..."
                      : test.attempt?.status === "IN_PROGRESS"
                      ? "RESUME TEST"
                      : test.attempt?.status === "SUBMITTED"
                      ? "COMPLETED"
                      : "START TEST"}
                    <span>→</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <div className="my-tests-footer">
        <div>
          <span className="footer-dot" />
          <strong>Secure Examination Environment</strong>
          <span>
            Camera & microphone monitoring activates only after starting a
            test.
          </span>
        </div>

        {typeof onBackToDashboard === "function" && (
          <button className="back-dashboard-button" onClick={onBackToDashboard}>
            ← Dashboard
          </button>
        )}
      </div>
    </div>
  );
}