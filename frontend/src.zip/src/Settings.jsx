﻿import { useEffect, useMemo, useState } from "react";
import "./Settings.css";

const API_URL = import.meta.env.VITE_API_URL || "https://testflow-pkbi.onrender.com";

const DEFAULT_SETTINGS = {
  theme: "dark",
  notifications: {
    testReminders: true,
    results: true,
    securityAlerts: true,
    emailNotifications: true,
  },
  examPreferences: {
    fullscreen: true,
    violationMonitoring: true,
    secureExamMode: true,
    autoSave: true,
  },
  general: {
    dateFormat: "DD/MM/YYYY",
    timeFormat: "12-hour",
    confirmLogout: true,
  },
};

function getToken() {
  return (
    localStorage.getItem("student_token") ||
    sessionStorage.getItem("student_token") ||
    localStorage.getItem("access_token") ||
    sessionStorage.getItem("access_token") ||
    ""
  );
}

function cloneDefaults() {
  return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
}

function mergeSettings(value = {}) {
  const defaults = cloneDefaults();
  return {
    ...defaults,
    ...value,
    notifications: {
      ...defaults.notifications,
      ...(value.notifications || {}),
    },
    examPreferences: {
      ...defaults.examPreferences,
      ...(value.examPreferences || {}),
    },
    general: {
      ...defaults.general,
      ...(value.general || {}),
    },
  };
}

function Settings() {
  const [profile, setProfile] = useState(null);
  const [settings, setSettings] = useState(cloneDefaults());
  const [name, setName] = useState(localStorage.getItem("student_name") || "");
  const [email, setEmail] = useState(localStorage.getItem("student_email") || "");
  const [studentId, setStudentId] = useState(
    () => String(localStorage.getItem("student_id") || "").trim(),
  );

  const [loading, setLoading] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const [passwords, setPasswords] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [securityLoading, setSecurityLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);

  const showMessage = (text, type = "success") => {
    setMessage(text);
    setMessageType(type);

    window.clearTimeout(window.__testflowSettingsMessageTimer);
    window.__testflowSettingsMessageTimer = window.setTimeout(() => {
      setMessage("");
      setMessageType("");
    }, 3500);
  };

  const loadSettings = async () => {
    const token = getToken();

    if (!token) {
      setLoading(false);
      showMessage("Your session has expired. Please log in again.", "error");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/api/student/settings`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {
        console.error("Non-JSON response received:", e);
      }

      if (!response.ok) {
        throw new Error(data.message || "Failed to load settings.");
      }

      const nextProfile = data.profile || {};
      const loadedName = nextProfile.name || name || "Student";
      const loadedEmail = nextProfile.email || email || "";
      const loadedStudentId = String(
        nextProfile.studentId || studentId || "",
      ).trim();

      const normalizedProfile = {
        ...nextProfile,
        studentId: loadedStudentId || null,
      };

      setProfile(normalizedProfile);
      setName(loadedName);
      setEmail(loadedEmail);

      if (loadedStudentId) {
        setStudentId(loadedStudentId);
        localStorage.setItem("student_id", loadedStudentId);
      }
      setSettings(mergeSettings(data.settings));

      localStorage.setItem("student_name", loadedName);
      localStorage.setItem("student_email", loadedEmail);
    } catch (error) {
      console.error("Settings load error:", error);
      showMessage(error.message || "Unable to load settings.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();

    return () => {
      window.clearTimeout(window.__testflowSettingsMessageTimer);
    };
  }, []);

  const updateNested = (section, key, value) => {
    setSettings((current) => ({
      ...current,
      [section]: {
        ...current[section],
        [key]: value,
      },
    }));
  };

  const saveProfile = async () => {
    const token = getToken();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedName || !trimmedEmail) {
      showMessage("Name and email are required.", "error");
      return;
    }

    setSavingProfile(true);

    try {
      const response = await fetch(`${API_URL}/api/student/profile`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: trimmedName,
          email: trimmedEmail,
        }),
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to update profile.");
      }

      const updatedProfile = data.profile || {};
      setProfile(updatedProfile);
      setName(updatedProfile.name || trimmedName);
      setEmail(updatedProfile.email || trimmedEmail);

      const updatedStudentId = String(
        updatedProfile.studentId || studentId || "",
      ).trim();

      if (updatedStudentId) {
        setStudentId(updatedStudentId);
        localStorage.setItem("student_id", updatedStudentId);
      }

      localStorage.setItem("student_name", updatedProfile.name || trimmedName);
      localStorage.setItem("student_email", updatedProfile.email || trimmedEmail);

      showMessage("Profile updated successfully.");
    } catch (error) {
      console.error("Profile update error:", error);
      showMessage(error.message || "Unable to update profile.", "error");
    } finally {
      setSavingProfile(false);
    }
  };

  const saveSettings = async () => {
    const token = getToken();
    setSavingSettings(true);

    try {
      const response = await fetch(`${API_URL}/api/student/settings`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(settings),
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to save settings.");
      }

      setSettings(mergeSettings(data.settings));
      showMessage("Settings saved successfully.");
    } catch (error) {
      console.error("Settings save error:", error);
      showMessage(error.message || "Unable to save settings.", "error");
    } finally {
      setSavingSettings(false);
    }
  };

  const resetSettings = async () => {
    if (!window.confirm("Restore all settings to their defaults?")) return;

    const token = getToken();
    setSavingSettings(true);

    try {
      const response = await fetch(`${API_URL}/api/student/settings/reset`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to reset settings.");
      }

      setSettings(mergeSettings(data.settings));
      showMessage("Settings restored to defaults.");
    } catch (error) {
      console.error("Settings reset error:", error);
      showMessage(error.message || "Unable to reset settings.", "error");
    } finally {
      setSavingSettings(false);
    }
  };

  const changePassword = async (event) => {
    event.preventDefault();
    const token = getToken();

    if (!passwords.currentPassword) {
      showMessage("Enter your current password.", "error");
      return;
    }
    if (passwords.newPassword.length < 6) {
      showMessage("New password must contain at least 6 characters.", "error");
      return;
    }
    if (passwords.newPassword !== passwords.confirmPassword) {
      showMessage("New password and confirmation do not match.", "error");
      return;
    }

    setPasswordLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/student/settings/change-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(passwords),
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to change password.");
      }

      setPasswords({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });

      showMessage("Password changed successfully.");
    } catch (error) {
      console.error("Password change error:", error);
      showMessage(error.message || "Unable to change password.", "error");
    } finally {
      setPasswordLoading(false);
    }
  };

  const logoutOtherSessions = async () => {
    const token = getToken();
    if (!window.confirm("Log out all other sessions for this account?")) return;

    setSecurityLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/student/settings/logout-other-sessions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to log out other sessions.");
      }

      showMessage(data.message || "Other sessions were logged out.");
    } catch (error) {
      console.error("Logout error:", error);
      showMessage(error.message || "Unable to log out other sessions.", "error");
    } finally {
      setSecurityLoading(false);
    }
  };

  const exportData = async () => {
    const token = getToken();
    setExportLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/student/settings/export-data`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      let data = {};
      try {
        data = await response.json();
      } catch (e) {}

      if (!response.ok) {
        throw new Error(data.message || "Unable to export account data.");
      }

      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "testflow-student-data.json";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);

      showMessage("Your account data has been downloaded.");
    } catch (error) {
      console.error("Export error:", error);
      showMessage(error.message || "Unable to export account data.", "error");
    } finally {
      setExportLoading(false);
    }
  };

  const initials = useMemo(() => {
    const source = name.trim() || "Student";
    return source
      .split(/\s+/)
      .map((part) => part[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();
  }, [name]);

  const pageTheme = settings.theme === "light" ? "light" : "dark";

  const displayStudentId = String(
    profile?.studentId || studentId || "",
  ).trim();

  return (
    <section className={`settings-page settings-${pageTheme}`}>
      <div className="settings-heading-row">
        <div className="settings-heading-copy">
          <div className="settings-eyebrow">STUDENT PORTAL • SETTINGS</div>
          <h1>Settings</h1>
          <p>Manage your account, security and examination preferences.</p>
          {loading && !displayStudentId && (
            <div className="settings-inline-loading" role="status">
              Loading your student profile…
            </div>
          )}
        </div>
      </div>

      {message && (
        <div className={`settings-message ${messageType}`} role="status">
          <span className="message-dot" />
          {message}
        </div>
      )}

      <div className="settings-grid">
        <div className="settings-main-column">
          <section className="settings-card profile-card">
            <CardTitle
              icon="◎"
              tone="blue"
              title="Profile"
              description="Your TESTFLOW student account information."
            />

            <div className="profile-preview">
              <div className="settings-avatar">{initials}</div>

              <div className="profile-preview-info">
                <strong>{name || "Student"}</strong>
                <span>{email || "Email not added yet"}</span>
              </div>

              <div className="student-id-box" aria-label="Student ID">
                <small>STUDENT ID</small>
                <strong>{displayStudentId || "—"}</strong>
              </div>
            </div>

            <div className="settings-form-grid">
              <label>
                <span>Full Name</span>
                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Enter your full name"
                  autoComplete="name"
                />
              </label>

              <label>
                <span>Email Address</span>
                <input
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="Enter your email address"
                  autoComplete="email"
                />
              </label>
            </div>

            <div className="settings-actions-row">
              <button
                className="settings-primary"
                type="button"
                onClick={saveProfile}
                disabled={savingProfile}
              >
                {savingProfile ? "Saving..." : "Save Profile"}
              </button>
            </div>
          </section>

          <section className="settings-card">
            <CardTitle
              icon="◇"
              tone="purple"
              title="Notifications"
              description="Choose the updates you want TESTFLOW to send you."
            />

            <SettingToggle
              title="Test reminders"
              description="Receive reminders about upcoming examinations."
              checked={settings.notifications.testReminders}
              onChange={(value) => updateNested("notifications", "testReminders", value)}
            />

            <SettingToggle
              title="Results and scores"
              description="Get notified when examination results are available."
              checked={settings.notifications.results}
              onChange={(value) => updateNested("notifications", "results", value)}
            />

            <SettingToggle
              title="Security alerts"
              description="Receive important account and examination security alerts."
              checked={settings.notifications.securityAlerts}
              onChange={(value) => updateNested("notifications", "securityAlerts", value)}
            />

            <SettingToggle
              title="Email notifications"
              description="Allow TESTFLOW to send account updates by email."
              checked={settings.notifications.emailNotifications}
              onChange={(value) => updateNested("notifications", "emailNotifications", value)}
              last
            />
          </section>

          <section className="settings-card">
            <CardTitle
              icon="✓"
              tone="green"
              title="Examination Preferences"
              description="Controls used when you take a secure examination."
            />

            <SettingToggle
              title="Enter fullscreen automatically"
              description="Open secure examinations in fullscreen mode when supported."
              checked={settings.examPreferences.fullscreen}
              onChange={(value) => updateNested("examPreferences", "fullscreen", value)}
            />

            <SettingToggle
              title="Violation monitoring"
              description="Allow TESTFLOW to monitor examination security violations."
              checked={settings.examPreferences.violationMonitoring}
              onChange={(value) => updateNested("examPreferences", "violationMonitoring", value)}
            />

            <SettingToggle
              title="Secure exam mode"
              description="Use TESTFLOW's protected examination experience."
              checked={settings.examPreferences.secureExamMode}
              onChange={(value) => updateNested("examPreferences", "secureExamMode", value)}
            />

            <SettingToggle
              title="Auto-save progress"
              description="Save supported examination progress automatically."
              checked={settings.examPreferences.autoSave}
              onChange={(value) => updateNested("examPreferences", "autoSave", value)}
              last
            />
          </section>
        </div>

        <div className="settings-side-column">
          <section className="settings-card compact-card">
            <CardTitle
              icon="◐"
              tone="orange"
              title="Appearance"
              description="Choose how TESTFLOW looks."
            />

            <div className="theme-options">
              {[
                ["system", "System", "Use device preference", "◯"],
                ["light", "Light", "Bright interface", "☼"],
                ["dark", "Dark", "Low-light interface", "◐"],
              ].map(([value, title, description, icon]) => (
                <button
                  type="button"
                  key={value}
                  className={`theme-option ${settings.theme === value ? "selected" : ""}`}
                  onClick={() =>
                    setSettings((current) => ({
                      ...current,
                      theme: value,
                    }))
                  }
                >
                  <span className="theme-icon">{icon}</span>
                  <span>
                    <strong>{title}</strong>
                    <small>{description}</small>
                  </span>
                  {settings.theme === value && <b>✓</b>}
                </button>
              ))}
            </div>
          </section>

          <section className="settings-card compact-card">
            <CardTitle
              icon="▻"
              tone="blue"
              title="General"
              description="Display and logout preferences."
            />

            <label className="settings-select">
              <span>Date format</span>
              <select
                value={settings.general.dateFormat}
                onChange={(event) => updateNested("general", "dateFormat", event.target.value)}
              >
                <option>DD/MM/YYYY</option>
                <option>MM/DD/YYYY</option>
                <option>YYYY-MM-DD</option>
              </select>
            </label>

            <label className="settings-select">
              <span>Time format</span>
              <select
                value={settings.general.timeFormat}
                onChange={(event) => updateNested("general", "timeFormat", event.target.value)}
              >
                <option>12-hour</option>
                <option>24-hour</option>
              </select>
            </label>

            <SettingToggle
              title="Confirm before logout"
              description="Ask before ending your TESTFLOW session."
              checked={settings.general.confirmLogout}
              onChange={(value) => updateNested("general", "confirmLogout", value)}
              last
            />
          </section>

          <section className="settings-card compact-card">
            <CardTitle
              icon="🔒"
              tone="red"
              title="Change Password"
              description="Update your student account password."
            />

            <form onSubmit={changePassword} className="password-form">
              <label>
                <span>Current password</span>
                <input
                  type="password"
                  value={passwords.currentPassword}
                  onChange={(event) =>
                    setPasswords({ ...passwords, currentPassword: event.target.value })
                  }
                  autoComplete="current-password"
                />
              </label>

              <label>
                <span>New password</span>
                <input
                  type="password"
                  value={passwords.newPassword}
                  onChange={(event) =>
                    setPasswords({ ...passwords, newPassword: event.target.value })
                  }
                  autoComplete="new-password"
                />
              </label>

              <label>
                <span>Confirm new password</span>
                <input
                  type="password"
                  value={passwords.confirmPassword}
                  onChange={(event) =>
                    setPasswords({ ...passwords, confirmPassword: event.target.value })
                  }
                  autoComplete="new-password"
                />
              </label>

              <button
                className="settings-secondary full-width"
                type="submit"
                disabled={passwordLoading}
              >
                {passwordLoading ? "Updating..." : "Change Password"}
              </button>
            </form>
          </section>

          <section className="settings-card compact-card security-card">
            <CardTitle
              icon="◆"
              tone="cyan"
              title="Account Security"
              description="Manage active sessions and your account data."
            />

            <div className="security-actions">
              <button
                className="security-action"
                type="button"
                onClick={logoutOtherSessions}
                disabled={securityLoading}
              >
                <span className="security-action-icon">↩</span>
                <span>
                  <strong>
                    {securityLoading ? "Signing out..." : "Log out other sessions"}
                  </strong>
                  <small>Keep this session active.</small>
                </span>
              </button>

              <button
                className="security-action"
                type="button"
                onClick={exportData}
                disabled={exportLoading}
              >
                <span className="security-action-icon">↓</span>
                <span>
                  <strong>
                    {exportLoading ? "Preparing data..." : "Download my data"}
                  </strong>
                  <small>Export your TESTFLOW account data.</small>
                </span>
              </button>
            </div>
          </section>
        </div>
      </div>

      <div className="settings-footer-actions">
        <button
          className="settings-danger-outline"
          type="button"
          onClick={resetSettings}
          disabled={savingSettings}
        >
          Reset Settings
        </button>

        <button
          className="settings-primary large"
          type="button"
          onClick={saveSettings}
          disabled={savingSettings}
        >
          {savingSettings ? "Saving Changes..." : "Save All Changes"}
        </button>
      </div>
    </section>
  );
}

function CardTitle({ icon, tone, title, description }) {
  return (
    <div className="settings-card-title">
      <div className={`settings-card-icon ${tone}`}>{icon}</div>
      <div>
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
    </div>
  );
}

function SettingToggle({ title, description, checked, onChange, last = false }) {
  return (
    <div className={`setting-toggle ${last ? "last" : ""}`}>
      <div className="setting-toggle-copy">
        <strong>{title}</strong>
        <p>{description}</p>
      </div>

      <button
        type="button"
        className={`toggle ${checked ? "on" : ""}`}
        aria-pressed={checked}
        aria-label={`${title}: ${checked ? "On" : "Off"}`}
        onClick={() => onChange(!checked)}
      >
        <span />
      </button>
    </div>
  );
}

export default Settings;